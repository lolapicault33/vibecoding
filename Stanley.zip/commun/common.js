/* ==========================================================================
   Éléments communs Stanley — à inclure dans TOUTES les pages (avant </body>) :
   <script src="commun/common.js"></script>
   Gère : menu mobile, état connecté dans le header, notifications, mentions
   légales, cookies, et les fonctions de compte client (window.Stanley).
   Démo : les comptes sont gardés dans le navigateur (localStorage). Un vrai site
   doit gérer les comptes côté serveur.
   ========================================================================== */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };

  /* ---------- Stockage (jamais bloquant) ---------- */
  function read(key, fallback) { try { var v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch (_) { return fallback; } }
  function write(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch (_) { return false; } }
  function remove(key) { try { localStorage.removeItem(key); } catch (_) {} }
  var USERS = "stanley-comptes", SESSION = "stanley-session", ORDERS = "stanley-commandes";

  /* ---------- Mot de passe : jamais stocké en clair ---------- */
  function toHex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ("0" + b.toString(16)).slice(-2); }).join(""); }
  function randomSalt() {
    var a = new Uint8Array(16);
    (window.crypto || {}).getRandomValues ? crypto.getRandomValues(a) : a.forEach(function (_, i) { a[i] = Math.floor(Math.random() * 256); });
    return toHex(a);
  }
  function hash(password, salt) {
    if (window.crypto && crypto.subtle) {
      var enc = new TextEncoder();
      return crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"])
        .then(function (k) { return crypto.subtle.deriveBits({ name: "PBKDF2", salt: enc.encode(salt), iterations: 100000, hash: "SHA-256" }, k, 256); })
        .then(toHex);
    }
    // Secours démo (navigateur sans crypto) : à ne pas utiliser en vrai.
    var h = 2166136261, s = salt + password;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return Promise.resolve("demo-" + (h >>> 0).toString(16));
  }

  /* ---------- Comptes clients ---------- */
  var normEmail = function (e) { return String(e || "").trim().toLowerCase(); };
  var Stanley = {
    getUsers: function () { return read(USERS, []); },
    getSession: function () { return read(SESSION, null); },
    getUser: function (email) { email = normEmail(email); return Stanley.getUsers().filter(function (u) { return u.email === email; })[0] || null; },
    register: function (data) {
      var email = normEmail(data.email);
      if (Stanley.getUser(email)) return Promise.resolve({ ok: false, error: "Un compte existe déjà avec cet e-mail. Essaie de te connecter." });
      var salt = randomSalt();
      return hash(data.password, salt).then(function (h) {
        var users = Stanley.getUsers();
        users.push({ name: data.name.trim(), email: email, salt: salt, hash: h, address: "", created: new Date().toISOString() });
        if (!write(USERS, users)) return { ok: false, error: "Le stockage du navigateur est indisponible : impossible de créer le compte." };
        write(SESSION, { email: email, name: data.name.trim() });
        return { ok: true };
      });
    },
    login: function (email, password) {
      email = normEmail(email);
      var fails = read("stanley-essais", { n: 0, until: 0 });
      if (Date.now() < fails.until) return Promise.resolve({ ok: false, error: "Trop d'essais. Réessaie dans quelques secondes." });
      var user = Stanley.getUser(email);
      // Même message d'erreur que le compte existe ou non : on ne révèle pas quels e-mails sont inscrits.
      var bad = { ok: false, error: "E-mail ou mot de passe incorrect." };
      var check = user ? hash(password, user.salt).then(function (h) { return h === user.hash; }) : Promise.resolve(false);
      return check.then(function (good) {
        if (!good) { fails.n += 1; if (fails.n >= 5) { fails = { n: 0, until: Date.now() + 30000 }; } write("stanley-essais", fails); return bad; }
        remove("stanley-essais");
        write(SESSION, { email: user.email, name: user.name });
        return { ok: true };
      });
    },
    logout: function () { remove(SESSION); },
    updateUser: function (email, patch) {
      var users = Stanley.getUsers();
      users.forEach(function (u) { if (u.email === normEmail(email)) { Object.keys(patch).forEach(function (k) { u[k] = patch[k]; }); } });
      var ok = write(USERS, users);
      var s = Stanley.getSession(); if (s && patch.name) { s.name = patch.name; write(SESSION, s); }
      return ok;
    },
    deleteUser: function (email) {
      write(USERS, Stanley.getUsers().filter(function (u) { return u.email !== normEmail(email); }));
      remove(SESSION);
    },
    getOrders: function (email) { return read(ORDERS, []).filter(function (o) { return o.customer && normEmail(o.customer.email) === normEmail(email); }); },
    toast: toast,
    show: show
  };
  window.Stanley = Stanley;

  /* ---------- Header : menu mobile, page courante, état connecté ---------- */
  var burger = $("#burger"), menu = $("#menu");
  if (burger && menu) {
    burger.addEventListener("click", function () { var open = menu.classList.toggle("open"); burger.setAttribute("aria-expanded", open); });
    menu.addEventListener("click", function () { menu.classList.remove("open"); burger.setAttribute("aria-expanded", "false"); });
  }
  var current = (location.pathname.split("/").pop() || "index.html").replace(".html", "") || "index";
  var navLink = document.querySelector('[data-nav="' + current + '"]');
  if (navLink) navLink.setAttribute("aria-current", "page");
  var session = Stanley.getSession(), accountLink = $("#account-link");
  if (accountLink && session) {
    accountLink.href = "mon-compte.html"; accountLink.classList.add("in");
    $("#who", accountLink).textContent = session.name.split(" ")[0];
    accountLink.setAttribute("aria-label", "Mon compte de " + session.name);
  }

  /* ---------- Notifications ---------- */
  var toastTimer;
  function toast(msg) {
    var t = $("#toast");
    if (!t) { t = document.createElement("div"); t.id = "toast"; t.setAttribute("role", "status"); t.hidden = true; document.body.appendChild(t); }
    t.textContent = msg; t.hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.hidden = true; }, 2800);
  }

  /* ---------- Modale commune ---------- */
  var dlg, panel;
  function ensureDialog() {
    if (dlg) return;
    dlg = document.createElement("dialog"); dlg.setAttribute("aria-labelledby", "c-dlg-title");
    panel = document.createElement("div"); panel.className = "panel"; dlg.appendChild(panel); document.body.appendChild(dlg);
    panel.addEventListener("click", function (e) { if (e.target.closest("[data-close]")) dlg.close(); });
  }
  function show(title, html) {
    ensureDialog();
    panel.innerHTML = '<button class="icon-btn close" type="button" data-close aria-label="Fermer"><svg class="icon" aria-hidden="true"><use href="#i-x"/></svg></button><h2 id="c-dlg-title"></h2><div id="dlg-body"></div>';
    $("#c-dlg-title", panel).textContent = title; $("#dlg-body", panel).innerHTML = html;
    if (!dlg.open) dlg.showModal();
    return panel;
  }

  /* ---------- Mentions légales et cookies ---------- */
  var LEGAL = {
    legal: ["Mentions légales", "<p>Site de démonstration de la refonte Stanley. Aucune vente réelle n'a lieu. L'éditeur et l'hébergeur sont à renseigner avant toute mise en ligne.</p>"],
    privacy: ["Confidentialité", "<p>Les informations de compte et de commande sont gardées uniquement sur cet appareil. Tu peux les effacer à tout moment depuis « Mon compte ». Les mots de passe ne sont jamais stockés en clair et les données de carte ne sont jamais enregistrées.</p>"]
  };
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-legal]"); if (!b) return;
    var l = LEGAL[b.dataset.legal];
    show(l[0], l[1] + '<div class="row"><button class="btn sec" type="button" data-close>Fermer</button></div>');
  });
  var cookies = $("#cookies");
  if (!cookies) {
    cookies = document.createElement("div"); cookies.id = "cookies"; cookies.setAttribute("role", "region"); cookies.setAttribute("aria-label", "Cookies"); cookies.hidden = true;
    cookies.innerHTML = "<p>Ce site n'utilise aucun cookie de suivi. Tu peux quand même choisir.</p><div class=\"row\"><button class=\"btn sec\" data-consent=\"refused\" type=\"button\">Tout refuser</button><button class=\"btn sec\" data-consent=\"accepted\" type=\"button\">Tout accepter</button></div>";
    document.body.appendChild(cookies);
  }
  cookies.addEventListener("click", function (e) { var b = e.target.closest("[data-consent]"); if (b) { try { localStorage.setItem("cookie-consent", b.dataset.consent); } catch (_) {} cookies.hidden = true; } });
  var bc = $("#btn-cookies"); if (bc) bc.addEventListener("click", function () { cookies.hidden = false; });
  var consent = null; try { consent = localStorage.getItem("cookie-consent"); } catch (_) {}
  if (!consent) cookies.hidden = false;
})();
